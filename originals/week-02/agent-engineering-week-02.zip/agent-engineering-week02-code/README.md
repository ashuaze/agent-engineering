# Agent 工程深度学习 · 第 02 期代码

Node.js >= 22，TypeScript 5.9，Zod 4.6，OpenAI Node SDK 7.10+。

```bash
npm install
npm run typecheck
npm test
npm run demo
```

真实 API（会产生费用，并使用 `store: true` 的服务端响应链）：

```bash
export OPENAI_API_KEY=...
export OPENAI_MODEL=gpt-5.4-mini
npm run live
```

这是教学实现，不是生产服务。`runAgent` 的上下文保存在内存中，没有 Run/Step 持久化、写操作审批恢复、数据库幂等记录或进程崩溃恢复。工具超时依赖 `AbortSignal` 的合作式取消；远端副作用无法靠 abort 撤销。`OpenAIModelSession` 必须每个 Run 单独创建，不能作为跨用户共享单例。示例工具返回模拟数据，不代表已执行真实业务租户隔离查询。
